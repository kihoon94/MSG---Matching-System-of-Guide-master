module.exports = {
    PORT: 8000,
    DB: "mongodb://localhost:27017/MSG"
}